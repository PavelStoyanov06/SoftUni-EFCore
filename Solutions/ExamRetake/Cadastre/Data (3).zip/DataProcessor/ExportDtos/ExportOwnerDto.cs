﻿using Cadastre.Data.Enumerations;

namespace Cadastre.DataProcessor.ExportDtos
{
    public class ExportOwnerDto
    {
        public string LastName { get; set; }

        public string MaritalStatus { get; set; }
    }
}