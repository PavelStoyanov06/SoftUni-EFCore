﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Cadastre;User Id=sa;Password=monkeyFlip930!;TrustServerCertificate=True;";
    }
}
